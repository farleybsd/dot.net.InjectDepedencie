﻿namespace ExampleDI.Services.Interfaces
{
    public interface IOperationTransient : IOperation
    {
        
    }
}