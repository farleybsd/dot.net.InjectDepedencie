﻿namespace ExampleDI.Services.Interfaces
{
    public interface IOperationSingleton : IOperation
    {
        
    }
}