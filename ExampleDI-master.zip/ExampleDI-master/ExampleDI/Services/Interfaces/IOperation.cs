﻿namespace ExampleDI.Services.Interfaces
{
    public interface IOperation
    {
        string OperationId { get; }
    }
}