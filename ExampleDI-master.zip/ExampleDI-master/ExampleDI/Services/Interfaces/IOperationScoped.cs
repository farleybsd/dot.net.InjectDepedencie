﻿namespace ExampleDI.Services.Interfaces
{
    public interface IOperationScoped : IOperation
    {
        
    }
}