﻿namespace ExampleDI.Services.Interfaces
{
    public interface IMyDependency
    {
        void WriteMessage(string message);
    }
}